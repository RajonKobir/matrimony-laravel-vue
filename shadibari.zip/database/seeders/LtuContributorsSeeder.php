<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class LtuContributorsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('ltu_contributors')->insert([
            'name' => 'admin',
            'email' => 'test@test.test',
            'password' => Hash::make('Test1234@'),
            'role' => 1,
        ]);
    }
}
