<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class UnionParishadSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json = File::get("database/data/bd-union-parishads.json");
        $union_parishads = json_decode($json);
        $union_parishads = $union_parishads->union_parishads;

        foreach ( $union_parishads as $union_parishad_key => $union_parishad_value ) {

            $union_parishad_array = explode(',', $union_parishad_value->union_parishads);

            foreach ($union_parishad_array as $single_union_parishad_key => $single_union_parishad) {
                DB::table('union_parishads')->insert([
                    'division_id' => (int)$union_parishad_value->division_id,
                    'district_id' => (int)$union_parishad_value->district_id,
                    'upazila' => $union_parishad_value->upazila,
                    'union_parishad' => trim($single_union_parishad),
                ]);
            }
        }
    }
}
