<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class BiodataSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $json = File::get("database/data/biodatas.json");
        $biodatas = json_decode($json);
        $biodatas = $biodatas->biodatas;

        foreach ( $biodatas as $biodata_key => $biodata_value ) {
            DB::table('biodatas')->insert([
                'user_id' => $biodata_value->user_id,
                'biodata_code' => $biodata_value->biodata_code,
                'biodata_completion' => $biodata_value->biodata_completion,
                'is_approved' => $biodata_value->is_approved,
                'pending_approve' => $biodata_value->pending_approve,
                'media_agreement' => $biodata_value->media_agreement,
                'running_tab' => $biodata_value->running_tab,
                'gender' => $biodata_value->gender,
                'birth_date' => $biodata_value->birth_date,
                'skin_color' => $biodata_value->skin_color,
                'height' => $biodata_value->height,
                'weight' => $biodata_value->weight,
                'blood_group' => $biodata_value->blood_group,
                'maritial_status' => $biodata_value->maritial_status,
                'have_children' => $biodata_value->have_children,
                'permanent_country' => $biodata_value->permanent_country,
                'permanent_division' => $biodata_value->permanent_division,
                'permanent_district' => $biodata_value->permanent_district,
                'permanent_upazila' => $biodata_value->permanent_upazila,
                'permanent_post_office' => $biodata_value->permanent_post_office,
                'permanent_post_code' => $biodata_value->permanent_post_code,
                'address_same' => $biodata_value->address_same,
                'address_hide' => $biodata_value->address_hide,
                'job_title' => $biodata_value->job_title,
                'job_details' => $biodata_value->job_details,
                'job_location' => $biodata_value->job_location,
                'monthly_income' => $biodata_value->monthly_income,
                'medium_of_study' => $biodata_value->medium_of_study,
                'general_highest_degree' => $biodata_value->general_highest_degree,
                'study_in_details' => $biodata_value->study_in_details,
                'honorable_degree_details' => $biodata_value->honorable_degree_details,
                'honorable_degree_place' => $biodata_value->honorable_degree_place,
                'five_waqt_salat' => $biodata_value->five_waqt_salat,
                'beard_quantity' => $biodata_value->beard_quantity,
                'pants_worn_style' => $biodata_value->pants_worn_style,
                'veiling_style' => $biodata_value->veiling_style,
                'islamic_studies' => $biodata_value->islamic_studies,
                'drugs_taken' => $biodata_value->drugs_taken,
                'dowry_deserve' => $biodata_value->dowry_deserve,
                'akida_majhhab' => $biodata_value->akida_majhhab,
                'three_choosen_alems' => $biodata_value->three_choosen_alems,
                'family_islam_maintain' => $biodata_value->family_islam_maintain,
                'physical_weakness' => $biodata_value->physical_weakness,
                'good_affairs' => $biodata_value->good_affairs,
                'religious_future_plan' => $biodata_value->religious_future_plan,
                'borka_wearing' => $biodata_value->borka_wearing,
                'nikab_with_borka' => $biodata_value->nikab_with_borka,
                'father_name' => $biodata_value->father_name,
                'father_desc' => $biodata_value->father_desc,
                'mother_name' => $biodata_value->mother_name,
                'mother_desc' => $biodata_value->mother_desc,
                'brother_sister_desc' => $biodata_value->brother_sister_desc,
                'property_and_income' => $biodata_value->property_and_income,
                'personal_maritial_agreement' => $biodata_value->personal_maritial_agreement,
                'family_maritial_agreement' => $biodata_value->family_maritial_agreement,
            ]);
        }
    }
}
