<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('proposals', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('sender_user_id');
            $table->string('sender_biodata_code', length: 20)->nullable();
            $table->bigInteger('receiver_user_id');
            $table->string('receiver_biodata_code', length: 20)->nullable();
            $table->dateTime('proposal_sent_datetime')->nullable();
            $table->string('proposal_status', length: 20)->default('Pending');
            $table->boolean('free_proposal')->default(true);
            $table->boolean('proposal_accepted')->default(false);
            $table->dateTime('proposal_accepted_datetime')->nullable();
            $table->boolean('proposal_rejected')->default(false);
            $table->dateTime('proposal_rejected_datetime')->nullable();
            $table->boolean('rejected_by_sender')->default(false);
            $table->boolean('rejected_by_receiver')->default(false);
            $table->boolean('rejected_by_admin')->default(false);
            $table->boolean('auto_received')->default(false);
            $table->dateTime('auto_received_datetime')->nullable();
            $table->boolean('in_trash')->default(false);
            $table->boolean('in_admin_trash')->default(false);
            $table->string('admin_comment', length: 100)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('proposals');
    }
};
