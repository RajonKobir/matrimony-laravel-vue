<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('union_parishads', function (Blueprint $table){
            $table->smallIncrements('id');
            $table->unsignedSmallInteger('country_id')->default(880);
            $table->unsignedSmallInteger('division_id')->nullable();
            $table->unsignedSmallInteger('district_id')->nullable();
            $table->string('upazila', 50)->nullable();
            $table->string('union_parishad', 50);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('union_parishads');
    }
};
