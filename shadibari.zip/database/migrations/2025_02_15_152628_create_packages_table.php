<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('packages', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id');
            $table->string('biodata_code', length: 20)->nullable();
            $table->boolean('accepted')->default(0);
            $table->dateTime('accepted_datetime')->nullable();
            $table->tinyInteger('package_number')->default(1);
            $table->tinyInteger('package_amount')->default(1);
            $table->string('payment_method', length: 20)->nullable();
            $table->string('transaction_id', length: 20)->nullable();
            $table->boolean('in_trash')->default(0);
            $table->boolean('in_admin_trash')->default(0);
            $table->string('admin_comment', length: 100)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('packages');
    }
};
