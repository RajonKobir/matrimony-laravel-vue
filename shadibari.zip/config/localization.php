<?php

return [

    'locales' => [
        'bn',
        'en',
    ],

];
