<?php

return [

    'locales' => [
        'en',
        'bn',
    ],

];
