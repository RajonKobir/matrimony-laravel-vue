<?php $__currentLoopData = $html; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $item; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\shadibari\vendor\open-admin-org\open-admin\resources\views\partials\html.blade.php ENDPATH**/ ?>