<?php echo $__env->make("admin::form._header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <input type="text" id="<?php echo e($id, false); ?>" name="<?php echo e($name, false); ?>" value="<?php echo e($value, false); ?>" class="form-control" readonly <?php echo $attributes; ?> />

<?php echo $__env->make("admin::form._footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shadibari\vendor\open-admin-org\open-admin\resources\views\form\id.blade.php ENDPATH**/ ?>