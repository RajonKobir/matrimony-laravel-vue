<div class="dashboard-title">
    Resources
</div>
<div class="dashboard-links">
    <a href="https://github.com/open-admin-org/open-admin" target="_blank">Github</a> -
    <a href="http://open-admin.org/docs"  target="_blank">Documentation</a> -
    <a href="http://open-admin.org/demo"  target="_blank">Demo</a>
</div><?php /**PATH D:\xampp\htdocs\shadibari\vendor\open-admin-org\open-admin\resources\views\dashboard\title.blade.php ENDPATH**/ ?>