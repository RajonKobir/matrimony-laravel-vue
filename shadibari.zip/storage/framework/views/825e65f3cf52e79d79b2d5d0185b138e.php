<?php $__env->startComponent('mail::message'); ?>
    <?php echo $mailData['message']; ?>


    Thanks,
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\xampp\htdocs\shadibari\resources\views/campaignEmail.blade.php ENDPATH**/ ?>