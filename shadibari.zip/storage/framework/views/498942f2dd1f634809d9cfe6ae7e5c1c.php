
<?php /**PATH D:\xampp\htdocs\shadibari\vendor\open-admin-org\open-admin\resources\views\grid\inline-edit\partials\popover.blade.php ENDPATH**/ ?>