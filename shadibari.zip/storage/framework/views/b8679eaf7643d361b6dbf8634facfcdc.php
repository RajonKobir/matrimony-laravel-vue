<?php $__env->startComponent('mail::message'); ?>
    # Hello

    You are receiving this email because we received a password reset request for your account.

    <?php $__env->startComponent('mail::button', ['url' => $link]); ?>
        Reset Password
    <?php echo $__env->renderComponent(); ?>

    This password reset link will expire in 60 minutes.

    If you did not request a password reset, no further action is required.

    Thanks,<br>
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\xampp\htdocs\shadibari\vendor\outhebox\laravel-translations\resources\views\mail\password.blade.php ENDPATH**/ ?>