<div class="<?php echo e($viewClass['form-group'], false); ?>">

    <label class="<?php echo e($viewClass['label'], false); ?> form-label"></label>

    <div class="<?php echo e($viewClass['field'], false); ?>">
        <input type='button' value='<?php echo e($label, false); ?>' class="btn <?php echo e($class, false); ?>" <?php echo $attributes; ?> />
    </div>
</div><?php /**PATH D:\xampp\htdocs\shadibari\vendor\open-admin-org\open-admin\resources\views\form\button.blade.php ENDPATH**/ ?>