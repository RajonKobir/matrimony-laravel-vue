<li class="nav-item">
    <a onclick="admin.ajax.reload();" class="nav-link container-refresh">
        <i class="icon-sync-alt"></i>
    </a>
</li><?php /**PATH D:\xampp\htdocs\shadibari\vendor\open-admin-org\open-admin\resources\views\components\refresh-btn.blade.php ENDPATH**/ ?>