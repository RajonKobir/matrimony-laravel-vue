<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\shadibari\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>