<div <?php echo $attributes; ?> >
    <button type="button" class="close" data-bs-dismiss="alert">×</button>
    <h4><i class="icon icon-<?php echo e($icon, false); ?>"></i> <?php echo e($title, false); ?></h4>
    <?php echo $content; ?>

</div><?php /**PATH D:\xampp\htdocs\shadibari\vendor\open-admin-org\open-admin\resources\views\widgets\alert.blade.php ENDPATH**/ ?>