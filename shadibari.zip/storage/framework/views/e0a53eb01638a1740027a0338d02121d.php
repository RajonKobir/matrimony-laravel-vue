<?php $__env->startComponent('mail::message'); ?>
    # Hello

    Someone has invited you to join their  translation team on <?php echo e(config('app.name')); ?>.

    <?php $__env->startComponent('mail::button', ['url' => $link]); ?>
        Accept Invitation
    <?php echo $__env->renderComponent(); ?>

    This invitation link will expire in 24 hours.

    If you did not request a password reset, no further action is required.

    Thanks,<br>
    <?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\xampp\htdocs\shadibari\vendor\outhebox\laravel-translations\resources\views\mail\invite.blade.php ENDPATH**/ ?>