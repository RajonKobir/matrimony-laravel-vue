<?php

return [
    'previous' => '&laquo; পূর্ববর্তী',
    'next' => 'পরবর্তী &raquo;',
];
