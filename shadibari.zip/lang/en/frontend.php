<?php

return [

    'homepage' => [
        'main_heading_1' => 'Bangladeshi Islamic',
        'main_heading_2' => 'Matrimony',
        'main_sub_heading_1' => 'It is now easier to find a religious spouse in your upazila.',
    ]

];
