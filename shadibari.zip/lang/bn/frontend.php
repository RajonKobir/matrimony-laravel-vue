<?php

return [

    'homepage' => [
        'main_heading_1' => 'বাংলাদেশী ইসলামিক',
        'main_heading_2' => 'ম্যাট্রিমনি',
        'main_sub_heading_1' => 'নিজ উপজেলায় দ্বীনদার পাত্রপাত্রী খোঁজা এখন সহজ',
    ]

];
